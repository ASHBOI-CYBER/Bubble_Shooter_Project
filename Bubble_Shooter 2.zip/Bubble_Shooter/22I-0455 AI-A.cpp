#include"stdafx.h"
#include<SFML\Graphics.hpp>
#include<SFML\Audio.hpp>
#include<iostream>

using namespace std;
using namespace sf;

//Function definitions.....
//WINDOWS FUNCTIONS........
void makemyMenu();//making structure of menu...
void draw(RenderWindow &window);//to draw menu...
void moveDown();//moving down in menu...
void moveUp();//moving up in menu...
void makemyOptions();//making structure of menu...
void draw1(RenderWindow &window);//to draw options...
void moveDown1();//moving down in options...
void moveUp1();//moving up in options...
void makegameover();//making structure of gameover window...
void draw2(RenderWindow &window);//to draw gameover window...
void makelevels();//making structure of levels window...
void draw3(RenderWindow &window);//to draw levels window...
void moveDown3();//moving down in levels....
void moveUp3();//moving up in levels....
//SWAPPING FUNCTIONS......
void changecolumn_pos(int p1column_pos, int p1column, int p1row, int p2column_pos, int p2column, int p2row);//to swap column_pos variables...
void changerow_pos(int p1row_pos, int p1column, int p1row, int p2row_pos, int p2column, int p2row);//to swap row_pos variables...
void changepics(int p1pics, int p1column, int p1row, int p2pics, int p2column, int p2row);//to swap pic variables...
void changepicfound(int p1found, int p1column, int p1row, int p2found, int p2column, int p2row);//to picfound variables...
void changecolumn(int p1column, int p1row, int p2column, int p2row);//to swap column variables...
void changerow(int p1column, int p1row, int p2column, int p2row);//to swap row variables...
void changevalues(int &a, int &b);//to swap values....
void Level1();//to make level 1 of game...
void Level2();//to make level 2 of game...

//Multiple Window Making...
int mainMenuSelected, optionSelected, gameoverSelected, levelsSelected;
Font font;
Text mainMenu[3], option[4], gameover[1], levels[2];

void makemyMenu()
{
	mainMenu[0].setFont(font);
	mainMenu[0].setFillColor(Color::Magenta);
	mainMenu[0].setString("Play");
	mainMenu[0].setCharacterSize(70);
	mainMenu[0].setPosition(100, 100);

	mainMenu[1].setFont(font);
	mainMenu[1].setFillColor(Color::Black);
	mainMenu[1].setString("Options");
	mainMenu[1].setCharacterSize(70);
	mainMenu[1].setPosition(96, 250);

	mainMenu[2].setFont(font);
	mainMenu[2].setFillColor(Color::Black);
	mainMenu[2].setString("Exit");
	mainMenu[2].setCharacterSize(70);
	mainMenu[2].setPosition(Vector2f(100, 400));

	mainMenuSelected = 0;
}
void draw(RenderWindow &window)
{
	for (int i = 0;i <= 2;i++)
	{
		window.draw(mainMenu[i]);
	}
}
void moveDown()
{
	mainMenu[mainMenuSelected].setFillColor(Color::Black);
	mainMenuSelected++;
	if (mainMenuSelected == 3)
	{
		mainMenuSelected = 0;
	}
	mainMenu[mainMenuSelected].setFillColor(Color::Magenta);
}
void moveUp()
{
	mainMenu[mainMenuSelected].setFillColor(Color::Black);
	mainMenuSelected--;
	if (mainMenuSelected == -1)
	{
		mainMenuSelected = 2;
	}
	mainMenu[mainMenuSelected].setFillColor(Color::Magenta);
}
void makemyOptions()
{
	option[0].setFont(font);
	option[0].setFillColor(Color::Magenta);
	option[0].setString("Increase Volume");
	option[0].setCharacterSize(50);
	option[0].setPosition(100, 100);

	option[1].setFont(font);
	option[1].setFillColor(Color::Black);
	option[1].setString("Decrease Volume");
	option[1].setCharacterSize(50);
	option[1].setPosition(100, 200);

	option[2].setFont(font);
	option[2].setFillColor(Color::Black);
	option[2].setString("Music On");
	option[2].setCharacterSize(50);
	option[2].setPosition(Vector2f(100, 300));

	option[3].setFont(font);
	option[3].setFillColor(Color::Black);
	option[3].setString("Music Off");
	option[3].setCharacterSize(50);
	option[3].setPosition(100, 400);

	optionSelected = 0;
}
void draw1(RenderWindow &window)
{
	for (int i = 0;i < 4;i++)
	{
		window.draw(option[i]);
	}
}
void moveDown1()
{
	option[optionSelected].setFillColor(Color::Black);
	optionSelected++;
	if (optionSelected == 4)
	{
		optionSelected = 0;
	}
	option[optionSelected].setFillColor(Color::Magenta);
}
void moveUp1()
{
	option[optionSelected].setFillColor(Color::Black);
	optionSelected--;
	if (optionSelected == -1)
	{
		optionSelected = 3;
	}
	option[optionSelected].setFillColor(Color::Magenta);
}

void makegameover()
{
	gameover[0].setFont(font);
	gameover[0].setFillColor(Color::Black);
	gameover[0].setString("Game Over");
	gameover[0].setCharacterSize(65);
	gameover[0].setPosition(200, 250);

	gameoverSelected = 0;
}
void draw2(RenderWindow &window)
{
	window.draw(gameover[0]);
}
void makelevels()
{
	levels[0].setFont(font);
	levels[0].setFillColor(Color::Magenta);
	levels[0].setString("Level 1 (Normal Mode)");
	levels[0].setCharacterSize(55);
	levels[0].setPosition(100, 150);

	levels[1].setFont(font);
	levels[1].setFillColor(Color::Black);
	levels[1].setString("Level 2 (Time Trail Mode)");
	levels[1].setCharacterSize(55);
	levels[1].setPosition(96, 300);
}
void draw3(RenderWindow &window)
{
	for (int i = 0;i < 2;i++)
	{
		window.draw(levels[i]);
	}
}
void moveDown3()
{
	levels[levelsSelected].setFillColor(Color::Black);
	levelsSelected++;
	if (levelsSelected == 2)
	{
		levelsSelected = 0;
	}
	levels[levelsSelected].setFillColor(Color::Magenta);
}
void moveUp3()
{
	levels[levelsSelected].setFillColor(Color::Black);
	levelsSelected--;
	if (levelsSelected == -1)
	{
		levelsSelected = 1;
	}
	levels[levelsSelected].setFillColor(Color::Magenta);
}

int column_pos[8][8], row_pos[8][8], column[8][8], row[8][8], pics[8][8], found[8][8];

//Swap Functions....
void changevalues(int &a, int &b)
{
	int temp;
	temp = a;
	a = b;
	b = temp;
}
void changecolumn_pos(int p1column_pos, int p1column, int p1row, int p2column_pos, int p2column, int p2row)
{
	changevalues(p1column, p2column);
	changevalues(p1row, p2row);

	column_pos[p1row][p1column] = p1column_pos;
	column_pos[p2row][p2column] = p2column_pos;
}
void changerow_pos(int p1row_pos, int p1column, int p1row, int p2row_pos, int p2column, int p2row)
{
	changevalues(p1column, p2column);
	changevalues(p1row, p2row);

	row_pos[p1row][p1column] = p1row_pos;
	row_pos[p2row][p2column] = p2row_pos;
}
void changepics(int p1pics, int p1column, int p1row, int p2pics, int p2column, int p2row)
{
	changevalues(p1column, p2column);
	changevalues(p1row, p2row);

	pics[p1row][p1column] = p1pics;
	pics[p2row][p2column] = p2pics;
}
void changepicfound(int p1found, int p1column, int p1row, int p2found, int p2column, int p2row)
{
	changevalues(p1column, p2column);
	changevalues(p1row, p2row);

	found[p1row][p1column] = p1found;
	found[p2row][p2column] = p2found;
}
void changecolumn(int p1column, int p1row, int p2column, int p2row)
{
	changevalues(p1column, p2column);
	changevalues(p1row, p2row);

	column[p1row][p1column] = p1column;
	column[p2row][p2column] = p2column;
}
void changerow(int p1column, int p1row, int p2column, int p2row)
{
	changevalues(p1column, p2column);
	changevalues(p1row, p2row);

	row[p1row][p1column] = p1row;
	row[p2row][p2column] = p2row;
}
void Game_over()
{
	Music go;
	go.openFromFile("gameover.wav");
	go.play();

	RenderWindow GameOver(VideoMode(1100, 629), "GameOver");
	Texture gameov;
	gameov.loadFromFile("menu.png");

	Sprite ovbackground(gameov);
	makegameover();

	if (!font.loadFromFile("Aloevera.ttf"))
	{
		cout << "Font is not loaded:" << endl;
	}
	while (GameOver.isOpen())
	{
		Event event1;
		while (GameOver.pollEvent(event1))
		{
			if (event1.type == Event::Closed)
			{
				GameOver.close();
			}
		}
		GameOver.clear();
		GameOver.draw(ovbackground);
		draw2(GameOver);
		GameOver.display();
	}
}
void Level1()
{
	int moves = 1000;
	int score = 0;
	int ts = 78; //tile size

	float size = 0;

	Vector2i offset(48, 24);
	Font scorefont;
	Text scoretext,movetext;
	string score_text;


	movetext.setFont(scorefont);//to set that font...
	movetext.setCharacterSize(40);//to set character size...
	movetext.setFillColor(Color::Black);//to set color of font...
	movetext.setPosition(800, 150);//to set position of that font...


	scorefont.loadFromFile("AlexandriaFLF.ttf");//to load font from folder...
	scoretext.setFont(scorefont);//to set that font...
	scoretext.setCharacterSize(50);//to set character size...
	scoretext.setFillColor(Color::Black);//to set color of font...
	scoretext.setPosition(800, 200);//to set position of that font...

	srand(time(0));

	RenderWindow app(VideoMode(1100, 629), "Level 1");
	app.setFramerateLimit(60);

	Texture t1, t2;
	t1.loadFromFile("background.png");
	t2.loadFromFile("gems.png");

	Sprite background(t1), gems(t2);

	//to store data of column and row positions and to generate random pics....
	for (int i = 1;i <= 8;i++)
	{
		for (int j = 1;j <= 8;j++)
		{
			column_pos[i][j] = j*ts;//column cursor position
			row_pos[i][j] = i*ts;//row cursor position
			column[i][j] = j;//array column position
			row[i][j] = i;//array row position
			pics[i][j] = rand() % 7 ;//to generate random pics
		}
	}

	int x0, y0, x1, y1, click = 0, temp = 0, temp1 = 0, temp2 = 0;
	Vector2i pos;

	while (app.isOpen() && moves > 0)
	{
		Event e;
		while (app.pollEvent(e))
		{
			if (e.type == Event::Closed)
			{
				app.close();
			}
			if (e.type == Event::MouseButtonPressed)
			{
				if (e.key.code == Mouse::Left)
				{
					if (!temp1 && !temp2)
					{
						click++;
					}
					pos = Mouse::getPosition(app) - offset;
				}
			}
		}
		//To check the position of mouse click...
		if (click == 1)
		{
			x0 = pos.x / ts + 1;
			y0 = pos.y / ts + 1;
		}
		if (click == 2)
		{
			moves--;
			x1 = pos.x / ts + 1;
			y1 = pos.y / ts + 1;
			if (abs(x1 - x0) + abs(y1 - y0) == 1)
			{
				changecolumn_pos(column_pos[y0][x0], column[y0][x0], row[y0][x0], column_pos[y1][x1], column[y1][x1], row[y1][x1]);
				changerow_pos(row_pos[y0][x0], column[y0][x0], row[y0][x0], row_pos[y1][x1], column[y1][x1], row[y1][x1]);
				changecolumn(column[y0][x0], row[y0][x0], column[y1][x1], row[y1][x1]);
				changerow(column[y0][x0], row[y0][x0], column[y1][x1], row[y1][x1]);
				changepics(pics[y0][x0], column[y0][x0], row[y0][x0], pics[y1][x1], column[y1][x1], row[y1][x1]);
				changepicfound(found[y0][x0], column[y0][x0], row[y0][x0], found[y1][x1], column[y1][x1], row[y1][x1]);

				temp1 = 1;
				click = 0;
			}
			else click = 1;
		}

		//Checking the match..
		for (int i = 1;i <= 8;i++)
		{
			for (int j = 1;j <= 8;j++)
			{
				if (pics[i][j] == pics[i + 1][j])
				{
					if (pics[i][j] == pics[i - 1][j])
					{
						for (int n = -1;n <= 1;n++)
						{
							score++;//when row match is found, score is increased...
							score_text = to_string(score);//to covert score into string to be displayed on screen..
							found[i + n][j] = found[i + n][j] + 1;
						}
					}
				}
				if (pics[i][j] == pics[i][j + 1])
				{
					if (pics[i][j] == pics[i][j - 1])
					{
						for (int n = -1;n <= 1;n++)
						{
							score++;//when column match is found, score is increased...
							score_text = to_string(score);//to covert score into string to be displayed on screen..
							found[i][j + n] = found[i][j + n]++;
						}
					}
				}
			}
		}

		temp2 = 0;
		for (int i = 1;i <= 8;i++)
		{
			for (int j = 1;j <= 8;j++)
			{
				int &px = column_pos[i][j];
				int &py = row_pos[i][j];
				int &pcolumn = column[i][j];
				int &prow = row[i][j];
				int &pa = pics[i][j];
				int &pb = found[i][j];
				int temp_1, temp_2;

				for (int n = 1;n < 5;n++)
				{
					temp_1 = px - pcolumn*ts;
					temp_2 = py - prow*ts;
					if (temp_1 != 0)
					{
						px = px - temp_1 / abs(temp_1);
					}
					if (temp_2 != 0)
					{
						py = py - temp_2 / abs(temp_2);
					}
				}
				if (temp_1 != 0 || temp_2 != 0)
				{
					temp2 = 1;
				}
			}
		}

		int temp = 0;
		for (int i = 1;i <= 8;i++)
		{
			for (int j = 1;j <= 8;j++)
			{
				temp = temp + found[i][j];
			}
		}

		//Swapping again if no match found

		if (temp1 && !temp2)
		{
			if (!temp)
			{
				changecolumn_pos(column_pos[y0][x0], column[y0][x0], row[y0][x0], column_pos[y1][x1], column[y1][x1], row[y1][x1]);
				changerow_pos(row_pos[y0][x0], column[y0][x0], row[y0][x0], row_pos[y1][x1], column[y1][x1], row[y1][x1]);
				changecolumn(column[y0][x0], row[y0][x0], column[y1][x1], row[y1][x1]);
				changerow(column[y0][x0], row[y0][x0], column[y1][x1], row[y1][x1]);
				changepics(pics[y0][x0], column[y0][x0], row[y0][x0], pics[y1][x1], column[y1][x1], row[y1][x1]);
				changepicfound(found[y0][x0], column[y0][x0], row[y0][x0], found[y1][x1], column[y1][x1], row[y1][x1]);
			}
			temp1 = 0;
		}
		if (!temp2)
		{
			for (int i = 8;i > 0;i--)
			{
				for (int j = 1;j <= 8;j++)
				{
					if (found[i][j] != 0)
					{
						for (int n = i;n > 0;n--)
						{
							if (found[n][j] == 0)
							{
								changecolumn_pos(column_pos[n][j], column[n][j], row[n][j], column_pos[i][j], column[i][j], row[i][j]);
								changerow_pos(row_pos[n][j], column[n][j], row[n][j], row_pos[i][j], column[i][j], row[i][j]);
								changecolumn(column[n][j], row[n][j], column[i][j], row[i][j]);
								changerow(column[n][j], row[n][j], column[i][j], row[i][j]);
								changepics(pics[n][j], column[n][j], row[n][j], pics[i][j], column[i][j], row[i][j]);
								changepicfound(found[n][j], column[n][j], row[n][j], found[i][j], column[i][j], row[i][j]);
								break;
							}
						}
					}
				}
			}

			for (int j = 1;j <= 8;j++)
			{
				for (int i = 8, n = 0;i > 0;i--)
				{
					if (found[i][j] != 0)
					{
						pics[i][j] = rand() % 7 ;
						row_pos[i][j] = -ts * n++;
						found[i][j] = 0;
					}
				}
			}

		}
		//to draw grid on the screen...
		app.draw(background);//to draw background photo....
		for (int i = 1; i <= 8;i++)
		{
			for (int j = 1;j <= 8;j++)
			{
				gems.setTextureRect(IntRect(pics[i][j] * 49, 0, 49, 49));
				gems.setPosition(column_pos[i][j], row_pos[i][j]);
				movetext.setString("Moves Left:" + to_string(moves));
				app.draw(movetext);
				scoretext.setString(score_text);//to load that score which we converted from int to string....
				app.draw(scoretext);//to draw that text on screen...
				gems.move(offset.x - ts, offset.y - ts);
				app.draw(gems);//to draw photo...
			}
		}
		app.display();//to display grid on screen...	
	}
	if (moves <= 0)
	{
		app.close();
		Game_over();
	}
}
void Level2()
{
	Clock clock;
	Time elapsed;

	int progress = 0;
	int moves = 250;
	int score = 0;
	int ts = 78; //tile size

	Vector2i offset(48, 24);
	Font scorefont;
	Text scoretext, timetext, movetext;
	string score_text, time_text;

	movetext.setFont(scorefont);//to set that font...
	movetext.setCharacterSize(40);//to set character size...
	movetext.setFillColor(Color::Black);//to set color of font...
	movetext.setPosition(800, 110);//to set position of that font...
	

	scorefont.loadFromFile("AlexandriaFLF.ttf");
	scoretext.setFont(scorefont);
	scoretext.setCharacterSize(50);
	scoretext.setFillColor(Color::Black);
	scoretext.setPosition(800, 150);

	timetext.setFont(scorefont);
	timetext.setCharacterSize(30);
	timetext.setFillColor(Color::Black);
	timetext.setPosition(800, 200);

	srand(time(0));

	RenderWindow app(VideoMode(1100, 629), "Level 2");
	app.setFramerateLimit(60);

	Texture t1, t2;
	t1.loadFromFile("background.png");
	t2.loadFromFile("gems.png");

	Sprite background(t1), gems(t2);
	for (int i = 1;i <= 8;i++)
	{
		for (int j = 1;j <= 8;j++)
		{
			column_pos[i][j] = j*ts;
			row_pos[i][j] = i*ts;
			column[i][j] = j;
			row[i][j] = i;
			pics[i][j] = rand() % 7 ;
		}
	}

	int x0, y0, x1, y1, click = 0, temp = 0, temp1 = 0, temp2 = 0;
	Vector2i pos;

	while (app.isOpen() && moves > 0 && score <= 2000  && (elapsed.asSeconds()) <= 100)
	{
		Event e;
		while (app.pollEvent(e))
		{
			if (e.type == Event::Closed)
			{
				app.close();
			}
			if (e.type == Event::MouseButtonPressed)
			{
				if (e.key.code == Mouse::Left)
				{
					if (!temp1 && !temp2)
					{
						click++;
					}
					pos = Mouse::getPosition(app) - offset;
				}
			}
		}
		//To check the position of mouse click...
		if (click == 1)
		{
			x0 = pos.x / ts + 1;
			y0 = pos.y / ts + 1;
		}
		if (click == 2)
		{
			moves--;
			x1 = pos.x / ts + 1;
			y1 = pos.y / ts + 1;
			if (abs(x1 - x0) + abs(y1 - y0) == 1)
			{
				changecolumn_pos(column_pos[y0][x0], column[y0][x0], row[y0][x0], column_pos[y1][x1], column[y1][x1], row[y1][x1]);
				changerow_pos(row_pos[y0][x0], column[y0][x0], row[y0][x0], row_pos[y1][x1], column[y1][x1], row[y1][x1]);
				changecolumn(column[y0][x0], row[y0][x0], column[y1][x1], row[y1][x1]);
				changerow(column[y0][x0], row[y0][x0], column[y1][x1], row[y1][x1]);
				changepics(pics[y0][x0], column[y0][x0], row[y0][x0], pics[y1][x1], column[y1][x1], row[y1][x1]);
				changepicfound(found[y0][x0], column[y0][x0], row[y0][x0], found[y1][x1], column[y1][x1], row[y1][x1]);

				temp1 = 1;
				click = 0;
			}
			else click = 1;
		}

		//Checking the match..
		for (int i = 1;i <= 8;i++)
		{
			for (int j = 1;j <= 8;j++)
			{
				if (pics[i][j] == pics[i + 1][j])
				{
					if (pics[i][j] == pics[i - 1][j])
					{
						for (int n = -1;n <= 1;n++)
						{
							score++;
							score_text = to_string(score);
							found[i + n][j] = found[i + n][j] + 1;
						}
					}
				}
				if (pics[i][j] == pics[i][j + 1])
				{
					if (pics[i][j] == pics[i][j - 1])
					{
						for (int n = -1;n <= 1;n++)
						{
							score++;
							score_text = to_string(score);
							found[i][j + n] = found[i][j + n]++;
						}
					}
				}
			}
		}

		temp2 = 0;
		for (int i = 1;i <= 8;i++)
		{
			for (int j = 1;j <= 8;j++)
			{
				int &px = column_pos[i][j];
				int &py = row_pos[i][j];
				int &pcolumn = column[i][j];
				int &prow = row[i][j];
				int &pa = pics[i][j];
				int &pb = found[i][j];
				int temp_1, temp_2;

				for (int n = 1;n < 5;n++)
				{
					temp_1 = px - pcolumn*ts;
					temp_2 = py - prow*ts;
					if (temp_1 != 0)
					{
						px = px - temp_1 / abs(temp_1);
					}
					if (temp_2 != 0)
					{
						py = py - temp_2 / abs(temp_2);
					}
				}
				if (temp_1 != 0 || temp_2 != 0)
				{
					temp2 = 1;
				}
			}
		}

		int temp = 0;
		for (int i = 1;i <= 8;i++)
		{
			for (int j = 1;j <= 8;j++)
			{
				temp = temp + found[i][j];
			}
		}

		//Swapping again if no match found

		if (temp1 && !temp2)
		{
			if (!temp1)
			{
				changecolumn_pos(column_pos[y0][x0], column[y0][x0], row[y0][x0], column_pos[y1][x1], column[y1][x1], row[y1][x1]);
				changerow_pos(row_pos[y0][x0], column[y0][x0], row[y0][x0], row_pos[y1][x1], column[y1][x1], row[y1][x1]);
				changecolumn(column[y0][x0], row[y0][x0], column[y1][x1], row[y1][x1]);
				changerow(column[y0][x0], row[y0][x0], column[y1][x1], row[y1][x1]);
				changepics(pics[y0][x0], column[y0][x0], row[y0][x0], pics[y1][x1], column[y1][x1], row[y1][x1]);
				changepicfound(found[y0][x0], column[y0][x0], row[y0][x0], found[y1][x1], column[y1][x1], row[y1][x1]);
			}
			temp1 = 0;
		}
		if (!temp2)
		{
			for (int i = 8;i > 0;i--)
			{
				for (int j = 1;j <= 8;j++)
				{
					if (found[i][j] != 0)
					{
						for (int n = i;n > 0;n--)
						{
							if (found[n][j] == 0)
							{
								changecolumn_pos(column_pos[n][j], column[n][j], row[n][j], column_pos[i][j], column[i][j], row[i][j]);
								changerow_pos(row_pos[n][j], column[n][j], row[n][j], row_pos[i][j], column[i][j], row[i][j]);
								changecolumn(column[n][j], row[n][j], column[i][j], row[i][j]);
								changerow(column[n][j], row[n][j], column[i][j], row[i][j]);
								changepics(pics[n][j], column[n][j], row[n][j], pics[i][j], column[i][j], row[i][j]);
								changepicfound(found[n][j], column[n][j], row[n][j], found[i][j], column[i][j], row[i][j]);
								break;
							}
						}
					}
				}
			}

			for (int j = 1;j <= 8;j++)
			{
				for (int i = 8, n = 0;i > 0;i--)
				{
					if (found[i][j] != 0)
					{
						pics[i][j] = rand() % 7 ;
						row_pos[i][j] = -ts * n++;
						found[i][j] = 0;
					}
				}
			}
		}
		app.draw(background);
		for (int i = 1; i <= 8;i++)
		{
			for (int j = 1;j <= 8;j++)
			{
				gems.setTextureRect(IntRect(pics[i][j] * 49, 0, 49, 49));
				gems.setPosition(column_pos[i][j], row_pos[i][j]);
				scoretext.setString(score_text);
				app.draw(scoretext);
				movetext.setString("Moves Left:" + to_string(moves));
				app.draw(movetext);
				elapsed = clock.getElapsedTime();//storing elapsed time in elapsed variable...
				time_text = "Time: 100 Seconds\nRequired Score: 2000\nTime Elapsed: " + to_string(int(elapsed.asSeconds()));//to store time in string...
				timetext.setString(time_text);//to load time which we converted from int to string....
				app.draw(timetext);//to draw time...
				gems.move(offset.x - ts, offset.y - ts);
				app.draw(gems);
			}
		}
		app.display();
	}
	if (moves <= 0 || score >= 2000 || (elapsed.asSeconds()) >= 100)
	{
		app.close();
		Game_over();
	}
}

int main()
{
	srand(time(0));

	RenderWindow MENU(VideoMode(1100, 629), "Ahmed Noorzai Menu");

	Music m;
	int m1 = 100;
	m.openFromFile("sound.ogg");

	Texture menu;
	menu.loadFromFile("menu.png");

	Sprite background(menu);

	makemyMenu();
	makegameover();

	if (!font.loadFromFile("Aloevera.ttf"))
	{
		cout << "Font is not loaded:" << endl;
	}

	m.play();
	m.setLoop(true);
	m.setVolume(m1);

	while (MENU.isOpen())
	{
		Event event;
		while (MENU.pollEvent(event))
		{
			if (event.type == Event::Closed)
			{
				MENU.close();
			}
			if (event.type == Event::KeyReleased)
			{
				if (event.key.code == Keyboard::Up)
				{
					moveUp();
					break;
				}
				if (event.key.code == Keyboard::Down)
				{
					moveDown();
					break;
				}
				if (event.key.code == Keyboard::Return)
				{
					if (mainMenuSelected == 0)
					{
						RenderWindow Level(VideoMode(1100, 629), "Level Select");

						Texture levels;
						levels.loadFromFile("menu.png");

						Sprite levelbackground(levels);
						makelevels();

						if (!font.loadFromFile("Aloevera.ttf"))
						{
							cout << "Font is not loaded:" << endl;
						}

						while (Level.isOpen())
						{
							Event event2;
							while (Level.pollEvent(event2))
							{
								if (event2.type == Event::Closed)
								{
									Level.close();
								}
								if (event2.type == Event::KeyReleased)
								{
									if (event2.key.code == Keyboard::Up)
									{
										moveUp3();
										break;
									}
									if (event2.key.code == Keyboard::Down)
									{
										moveDown3();
										break;
									}
									if (event2.key.code == Keyboard::Return)
									{
										if (levelsSelected == 0)
										{
											m.stop();
											MENU.close();
											Level1();
										}
										if (levelsSelected == 1)
										{
											m.stop();
											MENU.close();
											Level2();
										}
									}
									if (event2.key.code == Keyboard::Escape)
									{
										Level.close();
									}
								}
							}
							Level.clear();
							Level.draw(levelbackground);
							draw3(Level);
							Level.display();
						}

					}
					else if (mainMenuSelected == 1)
					{
						RenderWindow Options(VideoMode(1100, 629), "Options");

						Texture option;
						option.loadFromFile("menu.png");

						Sprite opbackground(option);
						makemyOptions();

						if (!font.loadFromFile("Aloevera.ttf"))
						{
							cout << "Font is not loaded:" << endl;
						}
						while (Options.isOpen())
						{
							Event event1;
							while (Options.pollEvent(event1))
							{
								if (event1.type == Event::Closed)
								{
									Options.close();
								}
								if (event1.type == Event::KeyReleased)
								{
									if (event1.key.code == Keyboard::Up)
									{
										moveUp1();
										break;
									}
									if (event1.key.code == Keyboard::Down)
									{
										moveDown1();
										break;
									}
									if (event1.key.code == Keyboard::Return)
									{
										if (optionSelected == 0)
										{
											m1 += 10;
											if (m1 >= 100)
											{
												m1 = 100;
												m.setVolume(m1);
											}
											m.setVolume(m1);
										}
										else if (optionSelected == 1)
										{
											m1 -= 10;
											if (m1 <= 0)
											{
												m1 = 0;
												m.setVolume(m1);
											}
											m.setVolume(m1);
										}
										else if (optionSelected == 2)
										{
											m.play();
										}
										else if (optionSelected == 3)
										{
											m.stop();
										}
									}
									if (event1.key.code == Keyboard::Escape)
									{
										Options.close();
									}
								}
							}
							Options.clear();
							Options.draw(opbackground);
							draw1(Options);
							Options.display();
						}
					}
					else if (mainMenuSelected == 2)
					{
						MENU.close();
					}
				}
			}
		}
		MENU.clear();
		MENU.draw(background);
		draw(MENU);
		MENU.display();
	}
	return 0;
}